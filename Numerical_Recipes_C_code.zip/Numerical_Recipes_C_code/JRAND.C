From xuli Sun Feb  3 14:50:44 1991
Message-Id: <6066.9102031450@csunb.cogs.susx.ac.uk>
From: Xu Li-Qun <xuli>
Date: Sun, 3 Feb 91 14:50:40 GMT
To: jims
Subject: random
Status: RO



#define   MULTIPLIER        25173      /* random number generator */
#define   MODULUS           65536
#define   INCREMENT         13849
#define   INITIAL_SEED         17
#define   FLOATING_MODULUS  65536.0

random()
  {
     static int seed = INITIAL_SEED;

     seed = (MULTIPLIER * seed + INCREMENT) % MODULUS;
     return (seed/FLOATING_MODULUS);
  }

